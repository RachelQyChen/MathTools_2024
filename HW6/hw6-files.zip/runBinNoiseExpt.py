﻿import base64, codecs 
sad = '\x72\x6f\x74\x31\x33'
gardo = 'aW1wb3J0IG51bXB5IGFzIG5wCmltcG9ydCBzY2lweQpmcm9tIHNjaXB5IGltcG9ydCBzcGVjaWFsCgojIHB5dGhvbiB2ZXJzaW9uIG9mIHJ1bkJpbk5vaXNlRXhwdApkZWYgcnVuQmluTm9pc2VFeHB0KGtlcm5lbCwgZHVyYXRpb24pOgogICAgIyBtYWtlIHN1cmUga2VybmVsI'
tram = 'TymVQRgENbtVPNtn2IlozIfVQ0tn2IlozIfYzMfLKE0MJ4bXDbXVPNtVPZtp3EcoKIfnFN9VQVdMT91LzkyXUWuozDbMUIlLKEco24fVTkyozq0nPueMKWhMJjcXFN8VQNhAFxtYFNkBjbtVPNtp3EcoKIfnFN9VQVhZPNdVPuhpP5lLJ5xo20hpzShMPuxqKWuqTyiovjtoaNhoJ'
krugz = 'F4KGtlcm5lbC5zaGFwZSkpIDwgMC41KSAtIDEuMAoKICAgICMgcHJvamVjdCBzdGltdWxpIG9udG8ga2VybmVsCiAgICBwcm9qZWN0aW9uID0gc3RpbXVsaSBAIGtlcm5lbAoKICAgICMgcHV0IHRocm91Z2ggbm9ubGluZWFyaXR5CiAgICBubCA9IDIgKiAoMSArIHNjaXB5LnN'
missy = 'jMJAcLJjhMKWzXQRhAFcjpz9dMJA0nJ9hVP0tZv41XFxXPvNtVPNwVTAioaMypaDtp3Ocn2HtpUWiLzSvnJkcqTyyplO0olOmpTyeMKZXVPNtVUAjnJgyplN9VT5jYaWuozEioF5lLJ5xXT5fYaAbLKOyJmOqXFN8VT5fPtbtVPNtpzI0qKWhVQRtXvOmpTyeMKZfVUA0nJ11oTxX'
ryndo = eval('\x67\x61\x72\x64\x6f') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x74\x72\x61\x6d\x2c\x73\x61\x64\x29')+ eval('\x6b\x72\x75\x67\x7a') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6d\x69\x73\x73\x79\x2c\x73\x61\x64\x29')
eval(compile(base64.b64decode(eval('\x72\x79\x6e\x64\x6f')),'<string>','exec'))
